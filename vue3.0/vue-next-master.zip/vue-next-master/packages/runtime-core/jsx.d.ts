declare namespace JSX {
  interface Element {}
  interface ElementClass {
    $props: {}
  }
  interface ElementAttributesProperty {
    $props: {}
  }
  interface IntrinsicElements {
    [name: string]: any
  }
}
